RAZOR PORTFOLIO

Pages:
- index.html: Home
- about.html: About
- skills.html: Skills
- contact.html: Contact

Shared files:
- style.css: Site layout and styling
- script.js: Mobile navigation

To preview:
1. Extract this ZIP.
2. Open the folder in Visual Studio Code.
3. Open index.html in a browser.

To edit:
- Change page text in the matching HTML file.
- Change colors and layout in style.css.
- Update social handles in contact.html when needed.

This is a static HTML, CSS, and JavaScript website. The source is intentionally editable so you can keep learning and make it your own.
